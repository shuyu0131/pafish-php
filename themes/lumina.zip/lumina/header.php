<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

// ── 私密文章守卫（对齐原版 header 头部检查） ──
if (isset($post) && is_array($post)) {
    $cf = lumina_fields($post['custom_fields'] ?? null);
    if (($cf['lumina_private'] ?? '') === 'y' && (int)($post['author_id'] ?? 0) !== (int)(current_user()['id'] ?? 0)) {
        http_response_code(404);
        echo render('error', ['status' => 404, 'message' => '内容不存在', 'backUrl' => url_to('/')]);
        exit;
    }
}

$lumina_favicon_fallback = lumina_asset_url('img/favicon.png');
$lumina_favicon = lumina_resolve_url((string)lumina_opt('site_favicon', $lumina_favicon_fallback), $lumina_favicon_fallback);
$lumina_favicon = lumina_versioned_url($lumina_favicon, __DIR__ . '/assets/img/favicon.png');
$lumina_favicon_path = parse_url($lumina_favicon, PHP_URL_PATH);
$lumina_favicon_ext = strtolower((string)pathinfo((string)$lumina_favicon_path, PATHINFO_EXTENSION));
$lumina_favicon_type = '';
if ($lumina_favicon_ext === 'png') $lumina_favicon_type = 'image/png';
elseif ($lumina_favicon_ext === 'svg') $lumina_favicon_type = 'image/svg+xml';
elseif ($lumina_favicon_ext === 'ico') $lumina_favicon_type = 'image/x-icon';

$lumina_logo_raw = trim((string)lumina_opt('site_logo', ''));
$lumina_logo = $lumina_logo_raw !== '' ? lumina_resolve_url($lumina_logo_raw, '') : '';
$lumina_iconfont = lumina_asset_url('iconfont/iconfont.css');
$lumina_vam_icon_styles = []; // pafish 不使用 VAM
$lumina_bg_raw = trim((string)lumina_opt('background_image', ''));
$lumina_bg = $lumina_bg_raw !== '' ? lumina_resolve_url($lumina_bg_raw, '') : '';
$lumina_cover = lumina_resolve_url((string)lumina_opt('header_cover', lumina_asset_url('img/homeimg.jpg')), lumina_asset_url('img/homeimg.jpg'));
$lumina_theme = trim((string)lumina_opt('theme_color', lumina_opt('accent_color', '#09c362')));
if ($lumina_theme === '') $lumina_theme = '#09c362';
$lumina_custom_css = trim((string)lumina_opt('custom_css', ''));
$lumina_dark = trim((string)lumina_opt('dark_mode', ''));
$lumina_footer_switch = trim((string)lumina_opt('footer_copyright_switch', 'y'));
if ($lumina_footer_switch === '') $lumina_footer_switch = 'y';
$lumina_ajax_nav_enabled = lumina_opt('enable_ajax_nav', 'n') === 'y' || theme_value('smooth_pagination','1') !== '0';
$lumina_ajax_progress_enabled = lumina_opt('ajax_progress_enable', 'y') === 'y';
$lumina_top_bgm_enabled = lumina_opt('top_bgm_enable', 'n') === 'y';
$lumina_top_bgm_url = trim((string)lumina_opt('top_bgm_url', ''));
$lumina_top_bgm_url = $lumina_top_bgm_url !== '' ? lumina_resolve_url($lumina_top_bgm_url, '') : '';
$lumina_top_bgm_autoplay = lumina_opt('top_bgm_autoplay', 'n') === 'y';
if ($lumina_top_bgm_url === '') $lumina_top_bgm_enabled = false;
$lumina_list_pagination = lumina_opt('list_pagination', 'n') === 'y';
$lumina_is_author_page = false; // 由 listing 覆盖
if (isset($luminaAuthorId) && (int)$luminaAuthorId > 0) $lumina_is_author_page = true;
$lumina_pc_layout = lumina_opt('home_layout_pc', 'double');
if ($lumina_pc_layout === 'triple') $lumina_pc_layout = 'double';
if (!in_array($lumina_pc_layout, ['single','double'], true)) $lumina_pc_layout = 'double';
if (isset($lumina_page_identity) && in_array($lumina_page_identity, ['user','article'], true)) $lumina_pc_layout = 'single';
$lumina_footer_hidden = ($lumina_footer_switch === 'n');

// 站点标题/关键词/描述（pafish 控制器已通过 $title/$description 传入，此处做兜底）
$site_title = $title ?? site_name();
$site_key = (string)settings('site_keywords', $site_title);
$site_description = $description ?? (string)settings('site_description', '');
if ($site_title === '') $site_title = site_name();
if ($site_description === '') $site_description = (string)settings('site_description', '');

$pageTitleForHead = (string)($site_title ?? '');
$siteNameForHead = site_name();
$fullTitle = $pageTitleForHead !== '' && $pageTitleForHead !== '首页' && $pageTitleForHead !== $siteNameForHead ? $pageTitleForHead . ' - ' . $siteNameForHead : $siteNameForHead;
$frontMeta = apply_filters('frontend_meta', [
    'title' => $fullTitle,
    'description' => $site_description,
    'canonical' => is_array($og ?? null) ? (string)($og['url'] ?? '') : '',
    'robots' => '',
], ['path' => parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/', 'template' => $GLOBALS['pafish_tpl_ctx'] ?? []]);
$fullTitle = is_string($frontMeta['title'] ?? null) ? $frontMeta['title'] : $fullTitle;
$site_description = is_string($frontMeta['description'] ?? null) ? $frontMeta['description'] : $site_description;
$canonicalHead = is_string($frontMeta['canonical'] ?? null) ? $frontMeta['canonical'] : '';
$robotsHead = is_string($frontMeta['robots'] ?? null) ? $frontMeta['robots'] : '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><?= e($fullTitle) ?></title>
    <?php if ($site_key !== ''): ?><meta name="keywords" content="<?= e($site_key) ?>"><?php endif; ?>
    <?php if ($site_description !== ''): ?><meta name="description" content="<?= e($site_description) ?>"><?php endif; ?>
    <?php if ($robotsHead !== ''): ?><meta name="robots" content="<?= e($robotsHead) ?>"><?php endif; ?>
    <?php if ($canonicalHead !== ''): ?><link rel="canonical" href="<?= e($canonicalHead) ?>"><?php endif; ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <link rel="icon" href="<?= e($lumina_favicon) ?>"<?= $lumina_favicon_type !== '' ? ' type="'.e($lumina_favicon_type).'"' : '' ?>>
    <link rel="icon" sizes="32x32" href="<?= e($lumina_favicon) ?>"<?= $lumina_favicon_type !== '' ? ' type="'.e($lumina_favicon_type).'"' : '' ?>>
    <link rel="shortcut icon" href="<?= e($lumina_favicon) ?>"<?= $lumina_favicon_type !== '' ? ' type="'.e($lumina_favicon_type).'"' : '' ?>>
    <link rel="apple-touch-icon" href="<?= e($lumina_favicon) ?>">
    <meta name="lumina-page-script" content="<?= e(isset($lumina_page_js) ? (string)$lumina_page_js : 'common') ?>">
    <meta name="lumina-page-identity" content="<?= e(isset($lumina_page_identity) ? (string)$lumina_page_identity : 'common') ?>">
    <?php foreach ($lumina_vam_icon_styles as $s): ?><link rel="stylesheet" href="<?= e($s) ?>"><?php endforeach; ?>
    <link rel="stylesheet" href="<?= e($lumina_iconfont) ?>">
    <link rel="stylesheet" type="text/css" href="<?= e(lumina_asset_url('vendor/dplayer/DPlayer.min.css')) ?>">
    <?php // 1:1 原版结构：style.css 由 Theme::layoutCss 内联注入，避免重复请求；此处仅保留 fancybox ?>
    <link rel="stylesheet" type="text/css" href="<?= e(lumina_asset_url('css/jquery.fancybox.min.css')) ?>">
    <?php // style.css 由下方 Theme::layoutCss 内联注入（themes/lumina/style.css），不再重复 link，避免 260KB 双份加载 ?>
    <?php do_action('head_inject', ['template' => $GLOBALS['pafish_tpl_ctx'] ?? []]); ?>
    <?php if ($lumina_theme !== ''): ?><style>:root{--theme:<?= e($lumina_theme) ?>;--themetm:<?= e($lumina_theme) ?>1a;}</style><?php endif; ?>
    <?php if ($lumina_bg !== ''): ?><style>body{background-image:url('<?= e($lumina_bg) ?>');}</style><?php endif; ?>
    <?php if ($lumina_custom_css !== ''): ?><style><?= $lumina_custom_css ?></style><?php endif; ?>
    <?php if (($layoutCss = \Pafish\Services\Theme::layoutCss('lumina')) !== null): ?><style data-theme="lumina"><?= $layoutCss ?></style><?php endif; ?>
    <script>
        window.LUMINA_BASE = <?= json_encode(url_to('/')) ?>;
        window.LUMINA = window.LUMINA || {};
        window.LUMINA.isLogin = <?= is_logged_in() ? 'true' : 'false' ?>;
        window.LUMINA.allowGuest = <?= settings('comments_require_login','false')==='true' ? 'false' : 'true' ?>;
        window.LUMINA.userName = <?= is_logged_in() ? json_encode((string)(current_user()['username'] ?? ''), JSON_UNESCAPED_UNICODE) : "''" ?>;
        window.LUMINA.paginationEnabled = <?= $lumina_list_pagination ? 'true' : 'false' ?>;
        window.LUMINA.ajaxNavEnabled = <?= $lumina_ajax_nav_enabled ? 'true' : 'false' ?>;
        window.LUMINA.ajaxProgressEnabled = <?= ($lumina_ajax_nav_enabled && $lumina_ajax_progress_enabled) ? 'true' : 'false' ?>;
        window.LUMINA.templateUrl = <?= json_encode(lumina_tpl_url(), JSON_UNESCAPED_UNICODE) ?>;
        window.LUMINA.pageScript = <?= isset($lumina_page_js) ? json_encode((string)$lumina_page_js) : "'common'" ?>;
        window.LUMINA.pageIdentity = <?= isset($lumina_page_identity) ? json_encode((string)$lumina_page_identity) : "'common'" ?>;
        window.LUMINA.topBgmEnabled = <?= $lumina_top_bgm_enabled ? 'true' : 'false' ?>;
        window.pafishApi = function(p){
            var q=p.indexOf('?'); var path=q>=0?p.slice(0,q):p; var query=q>=0?p.slice(q+1):'';
            return <?= json_encode(url_to('/api')) ?> + path + (query ? <?= json_encode(\Pafish\Core\Config::get('pretty_urls', true) ? '?' : '&') ?> + query : '');
        };
        window.LUMINA_API = {
            like: pafishApi('/post/' + '0' + '/like'),
            unlike: pafishApi('/post/' + '0' + '/like'),
            guestUnlike: <?= json_encode(url_to('/')) ?>,
            token: <?= json_encode(csrf_token()) ?>,
            likeEnabled: true
        };
        window.LUMINA_AUTH = {
            blogUrl: <?= json_encode(url_to('/')) ?>,
            loginCode: false,
            emailCode: false,
            allowSignup: <?= settings('site_allow_register','true')!=='false' ? 'true' : 'false' ?>
        };
    </script>
</head>
<body class="<?= e(trim(($lumina_dark==='dark'?'dark-theme':'').' '.($lumina_footer_hidden?'lumina-footer-off':'').' '.($lumina_is_author_page?'lumina-author-page':'').' lumina-pc-layout-'.$lumina_pc_layout)) ?>">
