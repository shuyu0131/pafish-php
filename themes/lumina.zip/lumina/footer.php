<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

$lumina_custom_js = trim((string)lumina_opt('custom_js', ''));
$lumina_footer_switch = trim((string)lumina_opt('footer_copyright_switch', 'y'));
if ($lumina_footer_switch === '') $lumina_footer_switch = 'y';
$lumina_search_enabled = lumina_opt('enable_search', 'y') === 'y' || theme_value('show_search','1') !== '0';
if (theme_value('show_search','1') === '0') $lumina_search_enabled = false;
$lumina_back_to_top_enabled = lumina_opt('enable_back_to_top', 'y') === 'y' || theme_value('show_back_to_top','1') !== '0';
if (theme_value('show_back_to_top','1') === '0') $lumina_back_to_top_enabled = false;
$lumina_theme_toggle_enabled = lumina_opt('enable_theme_toggle', 'n') === 'y';
$lumina_footer_ajax_nav_enabled = lumina_opt('enable_ajax_nav', 'n') === 'y' || theme_value('smooth_pagination','1') !== '0';
$lumina_footer_swup_enabled = false;
$lumina_custom_float_buttons = lumina_get_custom_float_buttons();
$lumina_float_hide_pages = lumina_opt_array('floating_hide_pages', []);
$lumina_current_page_identity = isset($lumina_page_identity) ? (string)$lumina_page_identity : 'common';
$lumina_float_hidden_here = in_array($lumina_current_page_identity, $lumina_float_hide_pages, true);
$lumina_theme_is_dark = lumina_opt('dark_mode', '') === 'dark';
$lumina_footer_custom = trim((string)lumina_opt('footer_copyright_text', theme_value('footer_text','')));
$lumina_footer_info = $lumina_footer_custom !== '' ? $lumina_footer_custom : '';
if ($lumina_footer_info !== '') {
    $lumina_footer_info = preg_replace('/\s*powered\s*by\s*emlog\s*/i', ' ', $lumina_footer_info) ?? $lumina_footer_info;
    $lumina_footer_info = trim($lumina_footer_info);
}
if ($lumina_footer_info === '') {
    $siteName = site_name();
    $lumina_footer_info = $siteName !== '' ? '© ' . date('Y') . ' ' . $siteName : '© ' . date('Y');
}
$icp_value = (string)settings('site_icp', '');
?>
    <?php if ($lumina_search_enabled): ?>
        <div class="so" id="lumina-search" aria-hidden="true" style="display:none">
            <div class="so-shell">
                <form class="sobd" id="lumina-search-form" method="get" action="<?= e(url_to('/search')) ?>" role="search">
                    <div class="sobd-field">
                        <i class="iconfont icon-sousuoxiao sobd-field-icon" aria-hidden="true"></i>
                        <input class="sobd-in" id="lumina-search-input" type="search" name="q" placeholder="搜索文章、标签或关键词" value="<?= e($_GET['q'] ?? $_GET['keyword'] ?? '') ?>" autocomplete="off" enterkeyhint="search" spellcheck="false">
                    </div>
                    <button class="sobd-bu" type="submit" aria-label="提交搜索">搜索</button>
                    <button class="sobd-close" type="button" data-action="search-close" aria-label="取消搜索" onclick="if(window.luminaCloseSearch){window.luminaCloseSearch();} return false;">
                        <span class="sobd-close-text">取消</span>
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>
    <?php if (!$lumina_float_hidden_here && ($lumina_search_enabled || $lumina_back_to_top_enabled || $lumina_theme_toggle_enabled || !empty($lumina_custom_float_buttons))): ?>
        <div class="sh-menu is-visible" id="sh-menu" data-force="1">
            <?php foreach ($lumina_custom_float_buttons as $button): ?>
                <a class="sh-menu-k lumina-custom-float-btn" href="<?= e($button['url']) ?>" target="<?= e($button['target']) ?>"<?= $button['target']==='_blank'?' rel="noopener noreferrer"':'' ?> aria-label="<?= e($button['title']) ?>">
                    <i class="<?= e($button['icon']) ?>" aria-hidden="true"></i>
                </a>
            <?php endforeach; ?>
            <?php if ($lumina_search_enabled): ?>
                <button type="button" class="sh-menu-k lumina-menu-search" data-action="search" aria-label="搜索" onclick="if(window.luminaOpenSearch){window.luminaOpenSearch();} return false;">
                    <i class="iconfont icon-sousuoxiao" aria-hidden="true"></i>
                </button>
            <?php endif; ?>
            <?php if ($lumina_theme_toggle_enabled): ?>
                <button type="button" class="sh-menu-k" id="day" data-bind="theme" aria-label="日夜切换" onclick="if(window.luminaToggleTheme){window.luminaToggleTheme();} return false;">
                    <i id="day-i" class="iconfont <?= $lumina_theme_is_dark ? 'icon-yueliang' : 'icon-ai250' ?>" aria-hidden="true"></i>
                </button>
            <?php endif; ?>
            <?php if ($lumina_back_to_top_enabled): ?>
                <button type="button" class="sh-menu-k lumina-backtop-btn" data-action="backtop" aria-label="返回顶部">
                    <i class="iconfont icon-fanhuidingbu lumina-backtop-icon" aria-hidden="true"></i>
                </button>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <div class="lumina-music-mini" id="lumina-music-mini" aria-hidden="true" style="display:none">
        <div class="lumina-music-mini-cover">
            <img id="lumina-music-mini-cover" src="<?= e(lumina_asset_url('img/musicba.jpg')) ?>" data-default-src="<?= e(lumina_asset_url('img/musicba.jpg')) ?>" alt="">
            <div class="lumina-music-mini-overlay">
                <button type="button" class="lumina-music-mini-btn" id="lumina-music-mini-toggle" aria-label="暂停播放">
                    <i class="iconfont icon-iconstop lumina-music-mini-icon-pause" aria-hidden="true"></i>
                    <i class="iconfont icon-sa4f56 lumina-music-mini-icon-play" aria-hidden="true"></i>
                </button>
                <button type="button" class="lumina-music-mini-btn" id="lumina-music-mini-close" aria-label="关闭音乐卡片">
                    <i class="iconfont icon-quxiao" aria-hidden="true"></i>
                </button>
            </div>
        </div>
    </div>

    <script src="<?= e(lumina_asset_url('js/jquery.min.js')) ?>"></script>
    <script src="<?= e(lumina_asset_url('js/jquery.fancybox.min.js')) ?>"></script>
    <script src="<?= e(lumina_asset_url('vendor/dplayer/DPlayer.min.js')) ?>"></script>
    <?php if (isset($lumina_page_js) && $lumina_page_js === 'index'): ?>
        <script src="<?= e(lumina_asset_url('js/index.js')) ?>"></script>
    <?php elseif (isset($lumina_page_js) && $lumina_page_js === 'home'): ?>
        <script src="<?= e(lumina_asset_url('js/index.js')) ?>"></script>
        <script src="<?= e(lumina_asset_url('js/home.js')) ?>"></script>
    <?php elseif (isset($lumina_page_js) && $lumina_page_js === 'view'): ?>
        <script src="<?= e(lumina_asset_url('js/index.js')) ?>"></script>
        <script src="<?= e(lumina_asset_url('js/view.js')) ?>"></script>
    <?php endif; ?>
    <?php if ($lumina_footer_ajax_nav_enabled && $lumina_footer_swup_enabled): ?>
        <script src="<?= e(lumina_asset_url('js/swup.umd.js')) ?>"></script>
    <?php endif; ?>
    <script src="<?= e(lumina_asset_url('js/theme.js')) ?>"></script>
    <?php if ($lumina_custom_js !== ''): ?><script><?= $lumina_custom_js ?></script><?php endif; ?>
    <?php do_action('footer_inject', ['template' => $GLOBALS['pafish_tpl_ctx'] ?? []]); ?>
    <?php do_action('index_footer'); ?>
</body>
</html>
