<?php

return [
  'onActivate' => function (object $ctx): void {},
];
